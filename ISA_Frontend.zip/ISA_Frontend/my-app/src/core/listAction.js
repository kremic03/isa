const listAction = {
    UPDATE: "update",
    DELETE: "delete",
    RELOAD: "reload",
    CREATE: "create",
    RESET: "reset",
}

export default listAction;