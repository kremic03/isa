 const testAction: {CHANGE_EMAIL: string, CHANGE_FIRST_NAME: string} = {
    CHANGE_EMAIL: 'changeEmail',
    CHANGE_FIRST_NAME: 'changeFirstName',
}
